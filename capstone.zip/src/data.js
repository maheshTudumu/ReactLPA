import axios from 'axios';

export default class data{
 


 static getAllProducts(cb){
  return axios.get('http://localhost:4000/products');
}
static saveProduct(product){
if(product.length < 1) {
			return new Promise((resolve, reject) => {				
				setTimeout(() => {
					reject("Product name must be at least 1 character.");
				}, 1000);
			});
		}	
return axios.post('http://localhost:4000/products', product);
}

static getUsers(){
  return axios.get('http://localhost:4000/users');
}
static saveUser(user){
return axios.post('http://localhost:4000/users', JSON.stringify(user),{headers: {'Content-Type': 'application/json'}});
}
static deleteProduct(id){
return axios.delete('http://localhost:4000/products/'+id);
}
static updateProduct(id){
console.log("id",id);
return axios.put('http://localhost:4000/products/'+id);
}
}
