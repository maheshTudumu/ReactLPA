import * as types from './actionTypes';
import dataApi from '../data';



export function loadProductsSuccess(products) {
  return { type: types.LOAD_PRODUCTS_SUCCESS, products};
}

export function addProductSuccess(product) {
  return { type: types.ADD_PRODUCT_SUCCESS, product};
}
export function deleteProductSuccess(product){
 return { type: types.DELETE_PRODUCT_SUCCESS, product};
}
export function updateProductSuccess(product){
 return { type: types.UPDATE_PRODUCT_SUCCESS, product};
}


export function loadProducts() {
  return function(dispatch){

    return dataApi.getAllProducts()
.then(products => {
      dispatch(loadProductsSuccess(products.data));
   }).catch(error => {
     throw(error);
    });
  };
}

export function addProduct(product) {
  return function (dispatch, getState) {
    return dataApi.saveProduct(product).then(product => {
      dispatch(addProductSuccess(product.data));
    }).catch(error => {
      throw(error);
    });
  };
}
export function deleteProduct(product) {
  return function (dispatch, getState) {
    return dataApi.deleteProduct(product.id).then(res => {
console.log("indel",res);
      dispatch(deleteProductSuccess(product));
    }).catch(error => {
      throw(error);
    });
  };
}
export function updateProduct(product) {
console.log("action",product);
  return function (dispatch, getState) {
    return dataApi.updateProduct(product.id).then(res => {
console.log("indel",res);
      dispatch(updateProductSuccess(product));
    }).catch(error => {
      throw(error);
    });
  };
}
