
import * as types from "../actions/actionTypes";
import initialState from './initialState';


const productReducer = (state = initialState.products, action) => {

  switch (action.type) {
    case types.LOAD_PRODUCTS_SUCCESS: {

      return action.products;


    }
   case types.ADD_PRODUCT_SUCCESS:
   
   return [
   
     ...state,
      
     Object.assign({}, action.product)
     
     ];
   case types.DELETE_PRODUCT_SUCCESS:
  { 
console.log("id in redu",action.product,action);
  let index = state.findIndex(x => x.id === action.product.id);
   state.splice(index, 1);
   return [
   
     ...state    
     ];
   }
  case types.UPDATE_PRODUCT_SUCCESS:
  { 
   let index = state.findIndex(x => x.id === action.product.id);
   state[index] = action.product;
   return [
   
     ...state    
     ];
   }
    default:
      return state;
  }
}
export default productReducer;