import React from 'react';





const Product = (props) => {
 
const productClicked = () => {
props.onProduct(props.innerdata);
}


 return (
 

<tr onClick={productClicked}> 
    <td>{props.innerdata.name}</td>
    <td>{props.innerdata.quantity}</td>
    <td>${props.innerdata.price}</td>
</tr>

 );


}
export default Product;