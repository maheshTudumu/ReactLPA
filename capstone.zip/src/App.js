import React from 'react';


import './App.css';
import LogIn from './components/Login';
import Register from './components/Register';
import AllProducts from './components/AllProductsPage';
import NotFoundPage from './components/NotFoundPage';
import AddProductPage from './components/AddProductPage';
import UpdateProduct from './components/UpdateProduct';
import DetailProductPage from './components/DetailProductPage';
import {BrowserRouter as Router,Route,Switch,NavLink} from 'react-router-dom';
import { Provider } from "react-redux";
import configureStore from "./store/configureStore";
import {loadProducts} from './actions/ProductActions';

const store = configureStore();
store.dispatch(loadProducts());

const Links =() =>{

return(
<nav>
<NavLink exact activeClassName="active" to="/" >About</NavLink>
<NavLink activeClassName="active" to="/products">All Products</NavLink>
</nav>
);

}

const App = () => {
 

const abouttext = "Implementing CapStone Project";

 return (
    
<Provider store={store}>
<Router>
<div className="App">
<Links/>
<Switch>
<Route path="/login" component={LogIn} />
<Route path="/register" component={Register} />
<Route path="/products" component={AllProducts} />
<Route exact path="/" render={() => <h1 style={{textAlign:'left',fontSize:'18px'}}>{abouttext}</h1>} /> 
<Route path="/addProduct" component={AddProductPage} />
<Route path="/updateproduct" component={UpdateProduct} />
<Route path="/productdetail" component={DetailProductPage} />
<Route component={NotFoundPage} /> 
</Switch>
</div>
</Router> 
</Provider>
);


}
export default App;
