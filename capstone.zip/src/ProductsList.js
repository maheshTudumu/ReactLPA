import React from 'react';


import Product from './Product';
import {connect} from 'react-redux';


const ProductsList = (props) => {
 

const onProductDetails = (e) => {
props.onParentClicked(e);
}

const datarows = props.products.map( x => (
<Product key={x.id} innerdata={x} onProduct={onProductDetails}>
</Product>
));

 return (

<>
<table>
 <thead>
  <tr>
    <th>Product Name</th>
    <th>Quantity</th>
    <th>Price</th>
  </tr>
 </thead>
 <tbody>
  {datarows}
 </tbody>
</table>
</>
 
  );


}
function mapStateToProps(state, ownProps) {
  return {
    products: state.products
  };
}
export default connect(mapStateToProps)(ProductsList);
