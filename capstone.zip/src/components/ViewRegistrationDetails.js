import React,{ useState ,useEffect} from 'react';


import dataApi from '../data';



let userdetails;

const ViewRegistrationDetails = (props) => {
 

const [content, setContent] = useState(false);

const fetchdetails = props.registrationdetails;
 return (
 
<div className="text-left">
<button className="btn btn-primary padd0" onClick = {() => setContent(!content) } >View Registration Details</button>
{content && <div class="row"><div class="col-sm-12 d-flex">
<div class="cols-m-6">
<div><span style={{fontWeight:'bold'}}>Email ID:</span> {fetchdetails.email}</div>
<div><span style={{fontWeight:'bold'}}>First Name:</span> {fetchdetails.firstname}</div>
<div><span style={{fontWeight:'bold'}}>Last Name:</span> {fetchdetails.lastname}</div>
</div>
<div class="cols-m-6">
<div className="text-right"><span style={{fontWeight:'bold'}}>Location:</span> {fetchdetails.location}</div>
<div className="text-right"><span style={{fontWeight:'bold'}}>Mobile:</span> {fetchdetails.mobile}</div>
</div>
</div></div>}  
 
      
</div>
 );


}
export default ViewRegistrationDetails;