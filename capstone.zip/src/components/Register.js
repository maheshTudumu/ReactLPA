import React from 'react';

import { withFormik, Form, Field,ErrorMessage } from 'formik';
import * as Yup from 'yup';
import * as productActions from '../actions/ProductActions';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import toastr from 'toastr';
import  '../styles/addform.css';
import dataApi from '../data';
import { withRouter,Link} from 'react-router-dom';
import {uuid} from 'uuidv4';

const RegisterForm = ({ values, errors, touched, isSubmitting,handleSubmit }) => (
<div className="form-content">
<h4>Registration</h4>
<Form>
<div>
<label>Email ID:</label>
<Field type="text" name="emailid" placeholder="Email ID" />
<br/><ErrorMessage name="emailid" />
</div>
<div>
<label>Password:</label>
<Field type="text" name="userpassword" placeholder="Password" />
<br/><ErrorMessage name="userpassword" />
</div>
<div>
<label>First name:</label>
<Field type="text" name="firstname" placeholder="First Name" />
<br/><ErrorMessage name="firstname" />
</div>
<div>
<label>Last name:</label>
<Field type="text" name="lastname" placeholder="Last Name" />
<br/><ErrorMessage name="lastname" />
</div>
<div>
<label>Location:</label>
<Field type="text" name="location" placeholder="Location" />
<br/><ErrorMessage name="location" />
</div>
<div>
<label>Mobile Number:</label>
<Field type="text" name="mobile" placeholder="Mobile number" />
<br/><ErrorMessage name="mobile" />
</div>
<br/>
<button type="submit">Save & Login</button>
</Form>
</div>
)
const FormikRegisterForm = withFormik({
mapPropsToValues({emailid,userpassword,firstname,lastname,location,mobile}){
return {
emailid: '',
userpassword: '',
firstname: '',
lastname: '',
location: '',
mobile: ''
}
},
validationSchema: Yup.object().shape({
emailid: Yup
    .string()
    .email()
    .required(),
userpassword: Yup
    .string()
    .required(),
firstname: Yup
    .string()
    .required(),
lastname: Yup
    .string()
    .required(),
location: Yup
    .string()
    .required(),
mobile: Yup
    .string()
    .required()
}),
handleSubmit(values,{ resetForm, setSubmitting, setErrors, props}){

const newuser = {
id:uuid(),
email:values.emailid,
password:values.userpassword,
firstname:values.firstname,
lastname: values.lastname,
location:values.location,
mobile:values.mobile
}
console.log("newuser",newuser);
//setSubmitting(false);
dataApi.saveUser(newuser).then((success) => {
console.log("new user posted successfully",success);
}).catch((error) => {
console.log(error);
});
props.history.push('/login');
}

})(RegisterForm)

function mapStateToProps(state, ownProps) {
  return {
    products: state.products
  };
}
function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(productActions, dispatch)
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(withRouter(FormikRegisterForm));
