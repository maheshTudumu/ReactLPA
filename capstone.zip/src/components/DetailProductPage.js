import React from 'react';


import {Link} from 'react-router-dom';



const DetailProductPage = (props) => {
 

const details = props.location.state.params;

return (
 

<div style={{textAlign:'left'}} className="back-btn">
<h2><b>Product Details: </b></h2>
<p><b>Product Name &nbsp;</b>: {details.name}</p>
<p><b>Quantity &nbsp;</b>: {details.quantity}</p>
<p><b>Price &nbsp;</b>: ${details.price}</p>

<Link to="/products">Back</Link>
</div>

 );


}
export default DetailProductPage;