import React from 'react';


import {uuid} from 'uuidv4';
import { withFormik, Form, Field } from 'formik';
import * as Yup from 'yup';
import * as productActions from '../actions/ProductActions';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import toastr from 'toastr';
import  '../styles/addform.css';
import {withRouter} from 'react-router-dom';

const UpdateForm = ({ values, errors, touched, isSubmitting,handleSubmit }) => (
<div className="form-content">
<h4>Update Product</h4>
<Form>
<div>
<label>Product Name:</label>
<Field type="text" name="productname" placeholder="Product Name" />
{touched.productname && errors.productname && <span style={{ color: 'red' }}>{errors.productname}</span>}
</div>
<div>
<label>Description:</label>
<Field type="text" name="description" placeholder="Product Description" />
{touched.description && errors.description && <span style={{ color: 'red' }}>{errors.description}</span>}
</div>
<div>
<label>Manufacturer:</label>
<Field type="text" name="manufacturer" placeholder="Product Manufacturer" />
{touched.manufacturer && errors.manufacturer && <span style={{ color: 'red' }}>{errors.manufacturer}</span>}
</div>
<div>
<label>Quantity:</label>
<Field type="number" name="quantity" placeholder="Quantity" />
{touched.quantity && errors.quantity && <span style={{ color: 'red' }}>{errors.quantity}</span>}
</div>
<div>
<label>Price ($):</label>
<Field type="text" name="price" placeholder="Price" />
{touched.price && errors.price && <span style={{ color: 'red' }}>{errors.price}</span>}
</div>
<br/>
<button type="submit" disabled={isSubmitting}>Save</button>
</Form>
</div>
)
const FormikUpdateForm = withFormik({
mapPropsToValues(props){
console.log("in update props",props);
let updatedData = props.location.state.params;
return {
productname:updatedData.name,
description:updatedData.description,
manufacturer:updatedData.manufacturer,
quantity: updatedData.quantity,
price: updatedData.price
}
},
validationSchema: Yup.object().shape({
productname: Yup.string().min(4,'Product name must be atleast 4 characters in length').required('Product name is required'),
description: Yup.string().min(4,'Description must be atleast 4 characters in length').required('Description is required'),
manufacturer: Yup.string().min(4,'Manufacturer must be atleast 4 characters in length').required('Manufacturer is required'),
quantity: Yup.string().required('Quantity is required'),
price: Yup.string().required('Price is required')
}),
handleSubmit(values,{ resetForm, setSubmitting, setErrors, props}){

const editedproduct = {
id:props.location.state.params.id,
name:values.productname,
description:values.description,
manufacturer:values.manufacturer,
quantity: values.quantity,
price:values.price
}
console.log("edited",editedproduct);
setSubmitting(false);
 props.actions.updateProduct(editedproduct).then((success) => { console.log("success",success)}).catch( (error) => console.log(error));
props.history.push('/products');
}


})(UpdateForm)

function mapStateToProps(state, ownProps) {
  return {
    products: state.products
  };
}
function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(productActions, dispatch)
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(withRouter(FormikUpdateForm));
