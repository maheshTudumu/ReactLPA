import React from 'react';


import { withRouter} from 'react-router-dom';
import ProductForm from './ProductForm';


const AddProductPage = (props) => {
 

const saveProduct = () => {
props.history.push('/products');
}

 return (
 
   <ProductForm onSave={saveProduct} />
 );


}


export default  withRouter(AddProductPage);
 