import React from 'react';


import ViewProductsList from './ViewProductsList';
import ViewRegistrationDetails from './ViewRegistrationDetails';
import {Link} from 'react-router-dom';
import {reactLocalStorage} from 'reactjs-localstorage';

const AllProducts = (props) => {
 
console.log("allp",props);
const productDisplay = (e) => {
if(window.confirm('Are you sure you want to view the details')){ 
props.history.push('/productdetail',{params: e });
}
}


let userdetails = reactLocalStorage.getObject("userdetails");
console.log("userdetails",userdetails);
return (
    
<>
<p style={{textAlign:'left',fontWeight:'bold'}}>Product List- Using Redux</p>
<ViewRegistrationDetails registrationdetails = {userdetails}/>
<ViewProductsList products = {props.products} onParentClicked={productDisplay}/>
<br/>
<Link to='/addProduct'>Add Product</Link>
</>
   );


}
function mapStateToProps(state, ownProps) {
console.log("allpage",state);
  return {
    products: state.products
  };
}

export default AllProducts;

