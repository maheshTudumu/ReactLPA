import React from 'react';





const NotFoundPage = () => {
 

 return (
 
      <div>Records not found</div>
 );


}
export default NotFoundPage;
 