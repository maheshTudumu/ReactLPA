import React from 'react';


import {uuid} from 'uuidv4';
import { withFormik, Form, Field } from 'formik';
import * as Yup from 'yup';
import * as productActions from '../actions/ProductActions';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import toastr from 'toastr';
import  '../styles/addform.css';

const ProductForm = ({ values, errors, touched, isSubmitting,handleSubmit }) => (
<div className="form-content">
<h4>Add Product</h4>
<Form>
<div>
<label>Product Name:</label>
<Field type="text" name="productname" placeholder="Product Name" />
{touched.productname && errors.productname && <span style={{ color: 'red' }}>{errors.productname}</span>}
</div>
<div>
<label>Description:</label>
<Field type="text" name="description" placeholder="Product Description" />
{touched.description && errors.description && <span style={{ color: 'red' }}>{errors.description}</span>}
</div>
<div>
<label>Manufacturer:</label>
<Field type="text" name="manufacturer" placeholder="Product Manufacturer" />
{touched.manufacturer && errors.manufacturer && <span style={{ color: 'red' }}>{errors.manufacturer}</span>}
</div>
<div>
<label>Quantity:</label>
<Field type="number" name="quantity" placeholder="Quantity" />
{touched.quantity && errors.quantity && <span style={{ color: 'red' }}>{errors.quantity}</span>}
</div>
<div>
<label>Price ($):</label>
<Field type="text" name="price" placeholder="Price" />
{touched.price && errors.price && <span style={{ color: 'red' }}>{errors.price}</span>}
</div>
<br/>
<button type="submit" disabled={isSubmitting}>ADD</button>
</Form>
</div>
)
const FormikProductForm = withFormik({
mapPropsToValues({productname,description,manufacturer,quantity,price,onSave}){
return {
productname:productname || '',
description:description || '',
manufacturer:manufacturer || '',
quantity: quantity || '',
price: price || ''
}
},
validationSchema: Yup.object().shape({
productname: Yup.string().min(4,'Product name must be atleast 4 characters in length').required('Product name is required'),
description: Yup.string().min(4,'Description must be atleast 4 characters in length').required('Description is required'),
manufacturer: Yup.string().min(4,'Manufacturer must be atleast 4 characters in length').required('Manufacturer is required'),
quantity: Yup.string().required('Quantity is required'),
price: Yup.string().required('Price is required')
}),
handleSubmit(values,{ resetForm, setSubmitting, setErrors, props}){

const addedproduct = {
id:uuid(),
name:values.productname,
description:values.description,
manufacturer:values.manufacturer,
quantity: values.quantity,
price:values.price
}
console.log("new",addedproduct);
setSubmitting(false);
props.actions.addProduct(addedproduct)
      			.then(()=> toastr.success('product added', {timeOut: 20000}))
      			.catch(error => {
        			alert(error);
      			});
		props.onSave(addedproduct);
}

})(ProductForm)

function mapStateToProps(state, ownProps) {
  return {
    products: state.products
  };
}
function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(productActions, dispatch)
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(FormikProductForm);
