import React from 'react';


import './../styles/productstyles.css';
import * as productActions from '../actions/ProductActions';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import {withRouter} from 'react-router-dom';

const Product = (props) => {
 
const productClicked = () => {
props.onProduct(props.innerdata);
}

const deleteProduct = () => {
console.log("del in prod",props.innerdata.id);
  props.actions.deleteProduct(props.innerdata).then((success) => { console.log("success",success)}).catch( (error) => console.log(error));
}
const updateProduct = () => {
props.history.push('/updateproduct',{params: props.innerdata});

}

 return (
 
<div className="col-sm-4 padd8">

<div className="book-container col-sm-12">
       
 <div className="col-sm-5 padd0">
      
  <div><img src="./../images/booksimg.jpeg" alt="img" className="img-fluid"/></div>
     
     <button className="btn" onClick={updateProduct}>Edit</button>
     
     <button className="btn" onClick={deleteProduct}>Delete</button>
      
    </div>
      
  <div className="col-sm-7 book-content padd8">
   
       <p><b>Name: &nbsp;</b>{props.innerdata.name}</p>
     
      <p><b>Description: &nbsp;</b>{props.innerdata.description}</p>
    
        <p><b>Manufacturer: &nbsp;</b>{props.innerdata.manufacturer}</p>
     
        <p><b>Price: &nbsp;</b>{props.innerdata.price}</p>
   
           <p><b>Quantity: &nbsp;</b>{props.innerdata.quantity}</p>
   
        </div>

  </div>
    
 </div>
      

 );


}
function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(productActions, dispatch)
  };
}
function mapStateToProps(state, ownProps) {
  return {
    products: state.products
  };
}
export default connect(mapStateToProps,mapDispatchToProps)(withRouter(Product));