import React from 'react';

import { withFormik, Form, Field,ErrorMessage } from 'formik';
import * as Yup from 'yup';
import * as productActions from '../actions/ProductActions';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
import toastr from 'toastr';
import  '../styles/addform.css';
import dataApi from '../data';
import { withRouter,Link} from 'react-router-dom';
import {reactLocalStorage} from 'reactjs-localstorage';


let isLoginFailed = false;
const LoginForm = ({ values,handleSubmit,isSubmitting}) => (
<div className="login-content">
<h6>User Login</h6>
<Form>
<div>
<label>Email ID</label>
<Field type="text" name="email" placeholder="Email ID" />
<br/><ErrorMessage name="email" />
</div>
<div>
<label>Password</label>
<Field type="text" name="password" placeholder="Password" />
<br/><ErrorMessage name="password" />
</div>
{isLoginFailed && <p style={{color:'red'}}>Invalid credentials</p>}
<br/>
<button type="submit">Sign In</button>
<p>New user: click on <Link to='/register'>Register</Link></p>
</Form>

</div>
)
const FormikLoginForm = withFormik({
mapPropsToValues({email,password}){
return {
email:'',
password:''
}
},
validationSchema: Yup.object().shape({
email: Yup
    .string()
    .email()
    .required(),
  password: Yup
    .string()
    .min(3)
    .max(16)
    .required()
}),
handleSubmit(values,{ setSubmitting, props}){

const logindetails = {
email:values.email,
password:values.password
}

dataApi.getUsers().then((x) => {
   
    let users = x.data;
   users.map((user) => {
   if(user.email === logindetails.email && user.password === logindetails.password){
      props.history.push('/products',{params:user});
      reactLocalStorage.setObject("userdetails", user);

     isLoginFailed = false;
   }else{
   isLoginFailed = true;
}
});
});
}

})(LoginForm)

function mapStateToProps(state, ownProps) {
  return {
    users: state.users
  };
}
function mapDispatchToProps(dispatch) {
  return {
    actions: bindActionCreators(productActions, dispatch)
  };
}

export default connect(mapStateToProps, mapDispatchToProps)(withRouter(FormikLoginForm));
