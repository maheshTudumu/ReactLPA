import React from 'react';


import Product from './Product';
import {connect} from 'react-redux';


const ProductsList = (props) => {
 
const onProductDetails = (e) => {
props.onParentClicked(e);
}

const datarows = props.products.map( (x) => (
<Product key={x.id} innerdata={x} onProduct={onProductDetails}>
</Product>
));

 return (

<>

<div className="container">
 
    <div className="row">

 <div className="col-sm-12">

<p className="padd8">Search your book: &nbsp; <input type="text" placeholder="Search by title" /></p>
</div>

 <div className="col-sm-12 d-flex" style={{flexWrap:'wrap'}}>

{datarows}
</div>
</div>
</div>
</>
 
  );


}
function mapStateToProps(state, ownProps) {
  return {
    products: state.products
  };
}
export default connect(mapStateToProps)(ProductsList);
